const { DataTypes } = require("sequelize");
const sequelize = require("../data/db");

const Notlar = sequelize.define(
  "notlar",
  {
    baslik: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    not: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    tarih: {
      type: DataTypes.DATE,
      allowNull: false,
    },
  },
  {
    timestamps: false,
  }
);
module.exports = Notlar;
