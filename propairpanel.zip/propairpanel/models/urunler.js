const { DataTypes } = require("sequelize");
const sequelize = require("../data/db");

const Urunler = sequelize.define(
  "urunler",
  {
    resim: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    isim: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    aciklama: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    fiyat: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    sayi: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
  },
  {
    timestamps: false,
  }
);
module.exports = Urunler;
