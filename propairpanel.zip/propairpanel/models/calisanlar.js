const { DataTypes } = require("sequelize");
const sequelize = require("../data/db");

const Calisanlar = sequelize.define(
  "calisanlar",
  {
    isim: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    unvan: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
  },
  {
    timestamps: false,
  }
);
module.exports = Calisanlar;
