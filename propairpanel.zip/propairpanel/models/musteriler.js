const { DataTypes } = require("sequelize");
const sequelize = require("../data/db");

const Musteriler = sequelize.define(
  "musteriler",
  {
    plaka: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    marka: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    isim: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    tarih: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    fiyat: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    eleman: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    aciklama: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
  },
  {
    timestamps: false,
  }
);
module.exports = Musteriler;
