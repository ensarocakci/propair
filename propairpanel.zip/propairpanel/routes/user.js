const express = require("express");
const router = express.Router();
const Musteriler = require('../models/musteriler');
const Urunler = require("../models/urunler");
const Notlar = require("../models/notlar");
const Calisanlar = require("../models/calisanlar");
const multer = require("multer");
const upload = multer({ dest: "./assets2/uploads" });
const fs = require("fs");
const path = require("path");
const imageUpload = require("../helpers/image-upload");
const User = require("../models/user");
const AltCategory = require("../models/altcategory");
const PDFDocument = require('pdfkit');
const Category = require("../models/category");
const puppeteer = require('puppeteer');

router.post("/calisanlar", async function (req, res) {
    const calisanid = req.body.calisanid;

    try {
        await Calisanlar.destroy({
            where: {
                id: calisanid,
            },
        });
        return res.redirect("/calisanlar");
    } catch (err) {
        console.log(err);
    }
});
router.post("/notlar", async function (req, res) {
    const notid = req.body.notid;

    try {
        await Notlar.destroy({
            where: {
                id: notid,
            },
        });
        return res.redirect("/notlar");
    } catch (err) {
        console.log(err);
    }
});
router.post("/urunler", async function (req, res) {
    const urunid = req.body.urunid;

    try {
        await Urunler.destroy({
            where: {
                id: urunid,
            },
        });
        return res.redirect("/urunler");
    } catch (err) {
        console.log(err);
    }
});
router.post("/musteriler", async function (req, res) {
    const musteriid = req.body.musteriid;

    try {
        await Musteriler.destroy({
            where: {
                id: musteriid,
            },
        });
        return res.redirect("/musteriler");
    } catch (err) {
        console.log(err);
    }
});

router.get("/urunler/:urunid", async function (req, res) {
    const urunid = req.params.urunid;
    try {
        const urun = await Urunler.findByPk(urunid);
        if (urun) {
            return res.render("users/edit/urun-edit", {
                urun: urun,
            });
        }
        res.redirect("/urunler");
    } catch (err) {
        console.log(err);
    }
});
router.get("/notlar/:notid", async function (req, res) {
    const notid = req.params.notid;
    try {
        const not = await Notlar.findByPk(notid);
        if (not) {
            return res.render("users/edit/not-edit", {
                not: not,
            });
        }
        res.redirect("/notlar");
    } catch (err) {
        console.log(err);
    }
});
router.get("/calisanlar/:calisanid", async function (req, res) {
    const calisanid = req.params.calisanid;
    try {
        const calisan = await Calisanlar.findByPk(calisanid);
        if (calisan) {
            return res.render("users/edit/calisan-edit", {
                calisan: calisan,
            });
        }
        res.redirect("/calisanlar");
    } catch (err) {
        console.log(err);
    }
});
router.get("/ayarlar/", async function (req, res) {
    try {
        const user = await User.findByPk(1);
        if (user) {
            return res.render("users/ayarlar", {
                user: user,
            });
        }
        res.redirect("/ayarlar");
    } catch (err) {
        console.log(err);
    }
});
router.get("/musteriler/:musteriid", async function (req, res) {
    const musteriid = req.params.musteriid;
    try {
        const musteri = await Musteriler.findByPk(musteriid);
        if (musteri) {
            return res.render("users/edit/musteri-edit", {
                musteri: musteri,
            });
        }
        res.redirect("/musteriler");
    } catch (err) {
        console.log(err);
    }
});

router.post(
    "/ayarlar", 
    async function (req, res) {
        const kadi = req.body.kadi;
        const sifre = req.body.sifre;
        try {
            await User.update(
                {
                    fullName:kadi,
                    password:sifre,
                },
                {
                    where: {
                        id: 1,
                    },
                }
            );
            return res.redirect("/");       
        } catch (err) {
            console.log(err);
        }
    }
);
router.post(
    "/urunler/:urunid", 
    imageUpload.upload.single("resim"),
    async function (req, res) {
        const urunid = req.params.urunid;
        const isim = req.body.isim;
        const fiyat = req.body.fiyat;
        const aciklama = req.body.aciklama;
        const sayi = req.body.sayi;
        let resim = req.body.resim;
        if (req.file) {
            resim = req.file.filename;

            fs.unlink("./assets2/uploads/" + req.body.resim, (err) => {});
        }
        try {
            await Urunler.update(
                {
                    resim:resim,
                    isim:isim,
                    aciklama:aciklama,
                    fiyat:fiyat,
                    sayi:sayi,
                },
                {
                    where: {
                        id: urunid,
                    },
                }
            );
            return res.redirect("/urunler");       
        } catch (err) {
            console.log(err);
        }
    }
);
router.post(
    "/notlar/:notid", 
    async function (req, res) {
        const notid = req.params.notid;
        const baslik = req.body.baslik;
        const not = req.body.not;
        const tarih = req.body.tarih;
        const gizlitarih = req.body.gizlitarih;
        try {
            await Notlar.update(
                {
                    baslik:baslik,
                    not:not,
                    tarih: tarih && tarih.trim() ? tarih : gizlitarih,
                },
                {
                    where: {
                        id: notid,
                    },
                }
            );
            return res.redirect("/notlar");       
        } catch (err) {
            console.log(err);
        }
    }
);
router.post(
    "/calisanlar/:calisanid", 
    async function (req, res) {
        const calisanid = req.params.calisanid;
        const isim = req.body.isim;
        const unvan = req.body.unvan;
        try {
            await Calisanlar.update(
                {
                    unvan:unvan,
                    isim:isim,
                },
                {
                    where: {
                        id: calisanid,
                    },
                }
            );
            return res.redirect("/calisanlar");       
        } catch (err) {
            console.log(err);
        }
    }
);
router.post(
    "/musteriler/:musteriid", 
    async function (req, res) {
        const musteriid = req.params.musteriid;
        const plaka = req.body.plaka;
        const marka = req.body.marka;
        const isim = req.body.isim;
        const tarih = req.body.tarih;
        const gizlitarih = req.body.gizlitarih;
        const fiyat = req.body.fiyat;
        const eleman = req.body.eleman;
        const aciklama = req.body.islem;
        try {
            await Musteriler.update(
                {
                    plaka:plaka,
                    marka:marka,
                    isim:isim,
                    tarih: tarih && tarih.trim() ? tarih : gizlitarih,

                    fiyat:fiyat,
                    eleman:eleman,
                    aciklama:aciklama,
                },
                {
                    where: {
                        id: musteriid,
                    },
                }
            );
            return res.redirect("/musteriler");       
        } catch (err) {
            console.log(err);
        }
    }
);

router.post("/not-create", async function (req, res) {
    const baslik = req.body.baslik;
    const not = req.body.not;
    const tarih = req.body.tarih;
    try {
        await Notlar.create({
            baslik:baslik,
            not:not,
            tarih:tarih,
        });
        return res.redirect("/notlar");
    } catch (err) {
        console.log(err);
    }
});
router.post("/urun-create", imageUpload.upload.single("resim"), async function (req, res) {
    const isim = req.body.isim;
    const resim = req.file.filename;
    const fiyat = req.body.fiyat;
    const aciklama = req.body.aciklama;
    const sayi = req.body.sayi;
    try {
        await Urunler.create({
            resim:resim,
            isim:isim,
            aciklama:aciklama,
            fiyat:fiyat,
            sayi:sayi,
        });
        return res.redirect("/urunler");
    } catch (err) {
        console.log(err);
    }
});
router.post("/musteri-create", async function (req, res) {
    const plaka = req.body.plaka;
    const marka = req.body.marka;
    const isim = req.body.isim;
    const tarih = req.body.tarih;
    const fiyat = req.body.fiyat;
    const eleman = req.body.eleman;
    const aciklama = req.body.islem;
    try {
        await Musteriler.create({
            plaka:plaka,
            marka:marka,
            isim:isim,
            tarih:tarih,
            fiyat:fiyat,
            eleman:eleman,
            aciklama:aciklama,
        });
        return res.redirect("/musteriler");
    } catch (err) {
        console.log(err);
    }
});
router.post("/calisan-create", async function (req, res) {
    const isim = req.body.isim;
    const unvan = req.body.unvan;
    try {
        await Calisanlar.create({
            unvan:unvan,
            isim:isim,
        });
        return res.redirect("/calisanlar");
    } catch (err) {
        console.log(err);
    }
});
router.get("/calisan-create", function (req, res) {
    try {
        res.render("users/edit/calisan-create");
    } catch (error) {
        
    }
});
router.get("/urun-create", function (req, res) {
    try {
        res.render("users/edit/urun-create");
    } catch (error) {
        
    }
});
router.get("/not-create", function (req, res) {
    try {
        res.render("users/edit/not-create");
    } catch (error) {
        
    }
});
router.post('/teklifler', async (req, res) => {
    try {
        const { action, categoryId, categoryName, altCategoryId, altCategoryName } = req.body;
        let modalProcessed = false;

        switch (action) {
            case 'addCategory':
                await Category.create({ name: categoryName });
                modalProcessed = true;
                break;

            case 'editCategory':
                if (!categoryId || !categoryName) {
                    return res.status(400).send('Kategori ID veya yeni ad belirtilmemiş');
                }
                await Category.update({ name: categoryName }, { where: { id: categoryId } });
                modalProcessed = true;
                break;

            case 'deleteCategory':
                if (!categoryId) {
                    return res.status(400).send('Kategori ID belirtilmemiş');
                }
                await Category.destroy({ where: { id: categoryId } });
                modalProcessed = true;
                break;

            case 'addAltCategory':
                if (!altCategoryName || !categoryId) {
                    return res.status(400).send('Alt kategori adı veya kategori ID belirtilmemiş');
                }
                await AltCategory.create({ altname: altCategoryName, categoryId: categoryId });
                modalProcessed = true;
                break;

            case 'editAltCategory':
                if (!altCategoryId || !altCategoryName) {
                    return res.status(400).send('Alt kategori ID veya yeni ad belirtilmemiş');
                }
                await AltCategory.update({ altname: altCategoryName }, { where: { id: altCategoryId } });
                modalProcessed = true;
                break;

            case 'deleteAltCategory':
                if (!altCategoryId) {
                    return res.status(400).send('Alt kategori ID belirtilmemiş');
                }
                await AltCategory.destroy({ where: { id: altCategoryId } });
                modalProcessed = true;
                break;

            default:
                modalProcessed = false;
                break;
        }

        // Modal işlemi yapılmamışsa PDF oluşturma
        if (!modalProcessed) {
            const teklif = req.body.teklif;
            const plaka = req.body.plaka;
            const marka = req.body.marka;
            const browser = await puppeteer.launch();
            const page = await browser.newPage();

            const htmlPath = path.join(__dirname, '../assets2/template.html');
            const cssPath = path.join(__dirname, '../assets2/styles.css');
            const logoPath = path.join(__dirname, '../assets2/beyaz.png'); 

            const teklifLines = teklif
            .split('\n')
            .map(line => line.trim())
            .filter(line => line.length > 0);

            const htmlContent = `
            <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PROPAIR</title>
    <style>
        ${await fs.promises.readFile(cssPath, 'utf-8')}
    </style>
</head>
<body>
    <div class="header">
        <img src="data:image/png;base64,${await fs.promises.readFile(logoPath, 'base64')}" alt="PROPAIR Logo" class="logo">
    </div>
    <div class="container">
        <div class="content">
            <p>Bu teklif sizler için özel olarak hazırlanmış olup, aşağıda detaylarını inceleyebilirsiniz.</p>
            <p><strong>Araç Marka/Model:</strong> ${marka} </p>
            <p><strong>Plakası:</strong> ${plaka} </p>
            <h2>PROPAIR</h2>
            <ul>
                <li>LACUNA CLEAR FULL PPF (5YIL) 50.000,00</li>
                <li>LACUNA MAXIMUM FULL PPF (10YIL) 70.000,00</li>
                ${teklifLines.map(line => `<li>${line}</li>`).join('\n')}
            </ul>
            <p>"Bu teklifte geçerli olan fiyatlar günlük kur farkına göre belirlenmiş olup günlük kur oranlarına göre değişkenlik gösterebilir.</p>
            <p>**Yukanda belirtilen ürün özelliklerine www.Lacuna.com.tr www.madico.com.tr adreslerinden ulaşabilirsiniz.</p>
        </div>
    </div>
    <div class="footer">
        <div class="contact">
            <div class="phone">
                <i class="phone-icon fas fa-phone"></i>
                <p>+90 534 925 6223</p>
            </div>
            <div class="location">
                <i class="location-icon fas fa-map-marker-alt"></i>
                <p>Cumhuriyet Mah. Çalım Sokak No:3/a Alya İş Merkezi</p>
            </div>
        </div>
    </div>
</body>
</html>`;

            await page.setContent(htmlContent, { waitUntil: 'networkidle0' });

            const pdfPath = path.join(__dirname, '../output.pdf');
            await page.pdf({ path: pdfPath, format: 'A4' });

            await browser.close();

            res.download(pdfPath);
        } else {
            res.redirect('/teklifler');
        }
    } catch (err) {
        console.error('Hata:', err);
        res.status(500).send('Bir hata oluştu.');
    }
});




router.get("/teklifler", async function (req, res) {
    try {
        const altcategory = await AltCategory.findAll();
        const category = await Category.findAll();
        const musteriler = await Musteriler.findAll();
        if (category) {
            return res.render("users/edit/teklifler", {
                category: category,
                altcategory: altcategory,
                musteriler: musteriler,
            });
        }
        res.redirect("/teklifler");
    } catch (err) {
        console.log(err);
    }
});
router.get("/musteri-create", function (req, res) {
    try {
        res.render("users/edit/musteri-create");
    } catch (error) {
        
    }
});
router.use("/notlar", async function (req, res) {
    const notlar = await Notlar.findAll();
    try {
        res.render("users/notlar", {
            notlar:notlar,
        });
    } catch (error) {
    }
});
router.use("/calisanlar", async function (req, res) {
    const calisanlar = await Calisanlar.findAll();
    try {
        res.render("users/calisanlar", {
            calisanlar:calisanlar,
        });
    } catch (error) {
        
    }
});
router.use("/urunler", async function (req, res) {
    const urunler = await Urunler.findAll();
    try {
        res.render("users/urunler", {
            urunler:urunler,
        });
    } catch (error) {
        
    }
});

// Müşteriler route
router.get('/musteriler', async (req, res) => {
    try {
        // Veritabanından tüm müşterileri al
        let musteriler = await Musteriler.findAll();

        // Filtreleme işlemi
        let filteredMusteriler;
        const filter = req.query.filter;
        const startOfDay = new Date().setHours(0, 0, 0, 0);
        const startOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1).getTime();
        const startOfYear = new Date(new Date().getFullYear(), 0, 1).getTime();

        switch (filter) {
            case 'günlük':
                filteredMusteriler = musteriler.filter(musteri => {
                    const musteriTarih = new Date(musteri.tarih).getTime();
                    return !isNaN(musteriTarih) && musteriTarih >= startOfDay && musteriTarih < (startOfDay + 86400000); // 24 saat
                });
                break;
            case 'aylık':
                filteredMusteriler = musteriler.filter(musteri => {
                    const musteriTarih = new Date(musteri.tarih).getTime();
                    return !isNaN(musteriTarih) && musteriTarih >= startOfMonth && musteriTarih < (startOfMonth + 2678400000); // 30 gün
                });
                break;
            case 'yıllık':
                filteredMusteriler = musteriler.filter(musteri => {
                    const musteriTarih = new Date(musteri.tarih).getTime();
                    return !isNaN(musteriTarih) && musteriTarih >= startOfYear && musteriTarih < (startOfYear + 31536000000); // 365 gün
                });
                break;
            default:
                filteredMusteriler = musteriler; // Eğer bir filtre yoksa tüm müşterileri göster
                break;
        }

        // Eğer PDF için bir id parametresi varsa
        if (req.query.pdf && req.query.id) {
            const musteriId = req.query.id;
            const musteri = musteriler.find(m => m.id == musteriId);

            if (musteri) {
                const browser = await puppeteer.launch();
                const page = await browser.newPage();

                const htmlContent = `
                <!DOCTYPE html>
                <html lang="tr">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Müşteri Bilgileri</title>
                    <style>
                        body { font-family: Arial, sans-serif; padding: 20px; }
                        .header, .footer { text-align: center; margin-bottom: 20px; }
                        .content { margin-bottom: 20px; }
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>${musteri.isim}</h1>
                    </div>
                    <div class="content">
                        <p><strong>Plaka:</strong> ${musteri.plaka}</p>
                        <p><strong>Marka:</strong> ${musteri.marka}</p>
                        <p><strong>Tarih:</strong> ${new Date(musteri.tarih).toLocaleDateString("tr-TR", { day: '2-digit', month: '2-digit', year: 'numeric' })}</p>
                        <p><strong>Fiyat:</strong> ${musteri.fiyat}</p>
                        <p><strong>Eleman:</strong> ${musteri.eleman}</p>
                        <p><strong>Açıklama:</strong> ${musteri.aciklama}</p>
                    </div>
                    <div class="footer">
                        <p>Bu belge müşteri bilgilerini içermektedir.</p>
                    </div>
                </body>
                </html>`;
                function convertTurkishChars(str) {
                    const mapping = {
                        'ç': 'c', 'Ç': 'C',
                        'ı': 'i', 'İ': 'I',
                        'ş': 's', 'Ş': 'S',
                        'ğ': 'g', 'Ğ': 'G',
                        'ü': 'u', 'Ü': 'U',
                        'ö': 'o', 'Ö': 'O',
                        'æ': 'ae', 'Æ': 'AE',
                        'ß': 'ss'
                    };
                
                    return str.split('').map(char => mapping[char] || char).join('');
                }
                const isimdosya = convertTurkishChars(musteri.isim).replace(/[^a-zA-Z0-9]/g, '_');

                await page.setContent(htmlContent, { waitUntil: 'networkidle0' });

                const pdfBuffer = await page.pdf({ format: 'A4' });

                await browser.close();

                res.setHeader('Content-Type', 'application/pdf');
                res.setHeader('Content-Disposition', `attachment; filename=PROPAIR - ${isimdosya}.pdf`);
                return res.send(pdfBuffer);
            } else {
                return res.status(404).send('Müşteri bulunamadı.');
            }
        }

        // Render işlemi
        res.render("users/musteri", {
            musteriler: filteredMusteriler,
        });
    } catch (error) {
        console.log(error);
        res.status(500).send("Sunucu Hatası");
    }
});

router.use("/", async function (req, res) {
    try {
        const musteriler = await Musteriler.findAll();
        const today = new Date();
        
        // Günlük, Aylık, Yıllık sayıları hesapla
        let gunlukMusteriSayisi = 0;
        let aylikMusteriSayisi = 0;
        let yillikMusteriSayisi = 0;
        let gunlukMusteriler = [];

        musteriler.forEach(musteri => {
            const musteriTarihi = new Date(musteri.tarih);
            
            // Günlük
            if (musteriTarihi.toDateString() === today.toDateString()) {
                gunlukMusteriSayisi++;
                gunlukMusteriler.push(musteri);
            }

            // Aylık
            if (
                musteriTarihi.getFullYear() === today.getFullYear() &&
                musteriTarihi.getMonth() === today.getMonth()
            ) {
                aylikMusteriSayisi++;
            }

            // Yıllık
            if (musteriTarihi.getFullYear() === today.getFullYear()) {
                yillikMusteriSayisi++;
            }
        });

        res.render("users/index", {
            musteriler: musteriler,
            gunlukMusteriSayisi,
            aylikMusteriSayisi,
            yillikMusteriSayisi,
            gunlukMusteriler
        });
    } catch (error) {
        console.log(error);
    }
});

module.exports = router;