const Musteriler = require("../models/musteriler");
const Urunler = require("../models/urunler");
const Category = require("../models/category");
const AltCategory = require("../models/altcategory");

async function populate() {
  const mustericount = await Musteriler.count();
  if (mustericount == 0) {
    await Musteriler.create({
      plaka: "54 AAF 333",
      isim: "İSİM",
      tarih: new Date("2024-01-12"),
      fiyat: "100",
      eleman: "eleman",
      aciklama: "aciklama"
    });
  }
  const uruncount = await Urunler.count();
  if (uruncount == 0) {
    await Urunler.create({
      isim: "İSİM",
      aciklama: "aciklama",
      fiyat: "150",
      sayi: "100",
    });
  }
  const kategoriler = await Category.count();
  if (kategoriler == 0) {
    await Category.create({
      name: "kategori-ismi-1",
    });
  }
  const secim = await AltCategory.count();
  if (secim == 0) {
    await AltCategory.create({
      altname: "kategori-alt-1",
      categoryId:7,
    });
  }
}

module.exports = populate;