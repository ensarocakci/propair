const express = require("express");
const app = express();
const path = require("path");
const sequelize = require("./data/db");
const AltCategory = require("./models/altcategory");
const Category = require("./models/category");

app.set("view engine", "ejs");

app.use("/static2", express.static(path.join(__dirname, "assets2")));
app.use("/libs", express.static(path.join(__dirname, "node_modules")));

app.use(express.urlencoded({ extended: false }));

const userRoutes = require("./routes/user");
// const authRoutes = require("./routes/auth");
// app.use("/account", authRoutes);
app.use(userRoutes);

const dummyData = require("./data/test");

(async () => {
  await sequelize.sync({ alter: true });
  await dummyData();
})();

Category.hasMany(AltCategory, {
  foreignKey: {
    name: "categoryId",
    allowNull: false,
    defaultValue: 1,
  },
});
AltCategory.belongsTo(Category);


app.listen(3000, () => {
  console.log("localhost 3000");
});